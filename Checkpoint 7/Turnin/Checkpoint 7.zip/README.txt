Compile as normal. Tests can be run with ./a.out < tests.slic.

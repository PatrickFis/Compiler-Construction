Compile as usual, and then run it on a slic program. I included five decently
sized test cases that work.
